@echo off
title Logitech Trackball Direction Tracker & Button HUD Server
color 0A
cls
echo ========================================================================
echo   LOGITECH TRACKBALL DIRECTION TRACKER & BUTTON HUD (OBS STREAM OVERLAY)
echo ========================================================================
echo.
echo   Starting desktop Win32 mouse hook & WebSocket broadcast server...
echo.
echo   [!] OBS Browser Source URL : http://localhost:8765/?mode=overlay^&bg=transparent
echo   [!] Streamer Control Panel : http://localhost:8765
echo.
echo ========================================================================
echo.

start "" "http://localhost:8765"
py server.py

pause
